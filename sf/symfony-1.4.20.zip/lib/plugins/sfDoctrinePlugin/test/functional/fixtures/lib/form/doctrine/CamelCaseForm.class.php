<?php

/**
 * CamelCase form.
 *
 * @package    form
 * @subpackage CamelCase
 * @version    SVN: $Id: CamelCaseForm.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class CamelCaseForm extends BaseCamelCaseForm
{
  public function configure()
  {
  }
}