<?php

/**
 * BlogArticleTranslation form.
 *
 * @package    symfony12
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: BlogArticleTranslationForm.class.php 23668 2009-11-07 12:51:07Z Kris.Wallsmith $
 */
class BlogArticleTranslationForm extends BaseBlogArticleTranslationForm
{
  public function configure()
  {
  }
}
