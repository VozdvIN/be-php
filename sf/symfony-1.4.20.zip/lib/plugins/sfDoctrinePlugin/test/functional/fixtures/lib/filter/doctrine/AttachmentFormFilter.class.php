<?php

/**
 * Attachment filter form.
 *
 * @package    symfony12
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: AttachmentFormFilter.class.php 24068 2009-11-17 06:39:35Z Kris.Wallsmith $
 */
class AttachmentFormFilter extends BaseAttachmentFormFilter
{
  public function configure()
  {
  }
}
