<?php

$this->installDir(dirname(__FILE__).'/skeleton');
$this->enablePlugin('sfDoctrinePlugin');
$this->reloadTasks();
