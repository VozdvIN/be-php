[?php include_partial('<?php echo $this->getModuleName() ?>/list_th_tabular', array('sort' => $sort)) ?]
