/*
  <?php echo $code.' '.$text."\n" ?>

  <?php echo $name."\n" ?>
  <?php echo $message."\n" ?>

<?php foreach ($traces as $trace): ?>
    <?php echo $trace."\n" ?>
<?php endforeach; ?>
*/
